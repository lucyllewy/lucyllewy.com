#SSIBench - the SSI Cluster benchmarking tool and framework.
#Copyright (C) 2006-07 Daniel Llewellyn aka the HoneyMonster.
#   (daniel@xyz-network.com)
#
#This program is free software; you can redistribute it and/or modify it under
#the terms of the GNU General Public License as published by the Free Software
#Foundation; either version 2 of the License, or (at your option) any later
#version.
#
#This program is distributed in the hope that it will be useful, but WITHOUT ANY
#WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
#PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License along with
#this program; if not, write to
#   the Free Software Foundation, Inc.,
#   59 Temple Place,
#   Suite 330,
#   Boston,
#   MA 02111-1307 USA

package plugin::zz_ssibench_default;
use strict;

sub new {
    my $class = shift;
    my $self = bless {}, $class;
    return $self;
}

sub setup {
    my $self = shift;

    print "enable default calculations? (Y/n): ";
    my $enabled = readline STDIN;
    $enabled =~ s/\s//g;
    $self->{enabled} = lc $enabled;
    $self->{enabled} = $enabled;
    $self->{enabled} = 'y' unless $self->{enabled} eq 'n';
    return if $self->{enabled} eq 'n';

    print "Default calculations...\n";
    print "loop1 value (1000): ";
    my $loop = readline STDIN;
    $loop =~ s/\s+//g;
    if ($loop =~ /^\d+$/) {
        $self->{loop1} = int($loop);
    } else { $self->{loop1} = 1000; }

    print "loop2 value (1000): ";
    $loop = readline STDIN;
    $loop =~ s/\s+//g;
    if ($loop =~ /^\d+$/) {
        $self->{loop2} = int($loop);
    } else { $self->{loop2} = 1000; }
}

sub execute {
    my $self = shift;
    return if $self->{enabled} ne 'y';

    for (my $i = 1; $i <= $self->{loop1}; $i++) {
        for (my $j = 1; $j <= $self->{loop2}; $j++) {
            my $total = ($i * rand);
            $total = $total / $j;
            $total = sqrt $total;
            $total = $total * ($i - $j);
        }
    }
}

sub get_results {
    my $self = shift;
    my $num_procs = shift;
    return 0 if $self->{enabled} ne 'y';

    return $num_procs * ($self->{loop1} * $self->{loop2} * 5);
}

1;
