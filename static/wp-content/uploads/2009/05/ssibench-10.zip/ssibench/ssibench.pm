#SSIBench - the SSI Cluster benchmarking tool and framework.
#Copyright (C) 2006-07 Daniel Llewellyn aka the HoneyMonster.
#   (daniel@xyz-network.com)
#
#This program is free software; you can redistribute it and/or modify it under
#the terms of the GNU General Public License as published by the Free Software
#Foundation; either version 2 of the License, or (at your option) any later
#version.
#
#This program is distributed in the hope that it will be useful, but WITHOUT ANY
#WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A
#PARTICULAR PURPOSE. See the GNU General Public License for more details.
#
#You should have received a copy of the GNU General Public License along with
#this program; if not, write to
#   the Free Software Foundation, Inc.,
#   59 Temple Place,
#   Suite 330,
#   Boston,
#   MA 02111-1307 USA

package ssibench;
use strict;
use Time::HiRes qw(gettimeofday tv_interval);

sub new {
    my $class = shift;
    my $self = bless {}, $class;

    my @plugins;
    opendir DIR, './plugin';
    while (my $entry = readdir DIR) {
        if ($entry ne '.' && $entry ne '..') {
            $entry =~ s/\.pm$//;
            push @plugins, $entry;
        }
    }
    if (!@plugins) { die("No plugins were found in the 'plugin' directory"); }
    my @handles;
    foreach(@plugins) {
        my $plugname = join '::', 'plugin', $_;
        eval "use $plugname;";
        if ($@) { die("Could not 'use' $plugname ($@)"); }
        push @handles, $plugname->new();
    }

    $self->{pluginHandles} = \@handles;
    return $self;
}

sub setup {
    my $self = shift;

    $_->setup() foreach @{$self->{pluginHandles}};

    print "Number of threads (10): ";
    my $numProcs = readline STDIN;
    $numProcs =~ s/\s+//g;
    if ($numProcs =~ /^\d+$/) {
        $numProcs = int($numProcs);
    } else { $numProcs = 10; }
    $self->{numProcs} = $numProcs;
}

sub execute {
    my $self = shift;
    my $starttime = [gettimeofday];
    my $i;
    for ($i = 0; $i < $self->{numProcs}; $i++) {
        my $pid = fork;
        if ($pid == 0) {
            foreach(@{$self->{pluginHandles}}) {
                $_->execute();
            }
            exit;
        }
    }
    my $reaped;
    do {
        $reaped = wait;
    } until ($reaped == -1);

    $self->{totaltime} = tv_interval($starttime);
}

sub get_results {
    my $self = shift;
    print "\n\n";
    my $totalcalcs = 0;
    my @result_texts;
    foreach(@{$self->{pluginHandles}}) {
        my $result = $_->get_results($self->{numProcs});
        if ($result =~ /^\d+$/) {
            $totalcalcs += $result;
            next;
        }
        push @result_texts, $result;
    }
    if (($#result_texts + 1) > 0) {
        print "$_\n" foreach @result_texts;
        print "\nPlus...\n";
    }
    print "$totalcalcs calculations\n";
    print "..all in $self->{totaltime}seconds\n";
}

1;
