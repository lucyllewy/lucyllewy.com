<?php

/*
Fotobook Management Panel
*/

// get facebook authorization token
$facebook = new FacebookAPI;

?>

<script language="javascript">
var manageUrl = '<?php echo FB_MANAGE_URL ?>';
</script>

<style type="text/css">
<?php echo file_get_contents(FB_PLUGIN_PATH.'styles/admin-styles.css'); ?>
</style>

<?php if(!$facebook->link_active()): ?>
<div id="message" class="error fade"><p>There is no Facebook account linked to this plugin.  Change that <a href="<?php echo FB_OPTIONS_URL ?>">here</a>.</p></div>
<?php endif; ?>

<?php if($fb_message): ?>
<div id="message" class="<?php echo $facebook->error ? 'error' : 'updated' ?> fade"><p><?php echo $fb_message ?></p></div>
<?php endif; ?>

<div class="wrap">
  <?php fb_info_box() ?>
  <div id="fb-panel">
    <h2 style="clear: none"><?php _e('Fotobook &rsaquo; Manage'); ?> <span><a href="<?php echo FB_OPTIONS_URL ?>">Change Settings &raquo;</a></span></h2>
    <p><?php _e('This is where you can import and manage your Facebook albums.  You can drag the albums to change the order.'); ?></p>
    <?php if(!fb_albums_page_is_set()): ?>
    <p><em>You must select a page for the photo gallery in the <a href="<?php echo FB_OPTIONS_URL ?>">Fotobook Options</a> panel before you can import albums.</em></p>
    <?php else: ?>
  
    <?php if($facebook->link_active()): ?>
    <div class="nav">
      <input type="button" class="button-secondary" name="Submit" onclick="getAlbums(); return false;" value="Get Albums" style="width: 100px" />
      <input type="button" class="button-secondary" name="Submit" onclick="resetOrder(); return false;" value="Order By Date" />
      <input type="button" class="button-secondary" name="Submit" onclick="removeAll(); return false;" value="Remove All" />  
  	  <span id="progress-container" style="display: none">&nbsp;&nbsp;<script>displayProgress('update-progress',0);</script></span>
    </div>
    <?php endif; ?>
    
    <div id="fb-manage">
      <p>Loading...</p>
      <script language="javascript">getAlbumsList(false);</script>
    </div>
    
    <?php endif; // condition checking if a gallery page is selected  ?>
  </div>
</div>