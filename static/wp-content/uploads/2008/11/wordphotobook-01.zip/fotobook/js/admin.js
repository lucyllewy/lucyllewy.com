var $j = jQuery.noConflict();

PeriodicalExecuter.prototype.registerCallback = function() {
  this.intervalID = setInterval(this.onTimerEvent.bind(this), this.frequency * 1000);
};

PeriodicalExecuter.prototype.stop = function() {
  clearInterval(this.intervalID);
};

window.onbeforeunload = function(e) {
  if($j('#grant-submit').attr('disabled'))
    return ('If this page is refreshed or changed between granting and applying permissions the activation process will not work.');
};

$j(document).ready(function() {
  $j('#grant-submit').removeAttr('disabled');
  $j('#grant').submit(function() {
    $j('#grant-submit').attr('disabled', 'true');
  });
  $j('#apply').submit(function() {
    $j('#grant-submit').removeAttr('disabled');
  });
});

function toggleHidden(el, aid) {
  var toggleHidden = new Ajax.Request(manageUrl, { method: 'post', parameters: 'hide='+aid });
  var row  = el.parentNode.parentNode.parentNode.parentNode;
  if(el.innerHTML == 'Hide') {
    el.innerHTML = 'Show';    
    Element.addClassName(row, 'disabled');
  } else {
    el.innerHTML = 'Hide';
    Element.removeClassName(row, 'disabled');
  }
}

function updateAlbumOrder() {
  var order = Sortable.sequence('fb-manage-list');
  var updateAlbumOrder = new Ajax.Request(manageUrl, { 
    method: 'post', 
    parameters: "order=" + order 
  });
  return true;
}

function getAlbumsList(message) {
  var params = "albums_list=true";
  if(message != '') params += "&message="+escape(message);
  var getAlbumsList = new Ajax.Updater('fb-manage', manageUrl, { 
    method: 'post', 
    parameters: params,
    evalScripts: true
  });
}

function getAlbums() {
  setProgress('update-progress', 0);
  Effect.Appear('progress-container');
  Element.addClassName('fb-manage-list', 'disabled');
  var getAlbums = new Ajax.Request(manageUrl, { 
    method: 'post', 
    parameters: "update=true", 
    onComplete: getAlbumsComplete
  });
  var pe = new PeriodicalExecuter(updateProgressBar, 4);
  function getAlbumsComplete(request) {
    pe.stop(); 
    setProgress('update-progress', 100);
    var response = request.responseText;
    getAlbumsList(response);
    Effect.Fade('progress-container'); 
  }
}

function updateProgressBar() {
  var getProgress = new Ajax.Request(manageUrl, { 
    method: 'post', 
    parameters: "update=true&progress=true", 
    onComplete: progressResponse 
  });
  function progressResponse(request) {
    var progress = request.responseText;
    setProgress('update-progress', progress);
  }
}

function resetOrder() {
  var resetOrder = new Ajax.Request(manageUrl, { 
    method: 'post', 
    parameters: "reset_order=true", 
    onComplete: function(request) { 
      getAlbumsList(request.responseText); 
    } 
  });
}

function removeAll() {
  var removeAll = new Ajax.Request(manageUrl, { 
    method: 'post', 
    parameters: "remove_all=true", 
    onComplete: function(request) { 
      getAlbumsList(request.responseText); 
    } 
  });
}

function changeStylesheet(obj) {
  var styles = $('fb-stylesheets').getElementsByTagName('textarea');
  for(i = 0; i < styles.length; i++) {
    Element.hide(styles[i].parentNode);
  }
  Element.show(obj.value+'-stylesheet');
}
