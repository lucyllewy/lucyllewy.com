#!/bin/sh

# Script by eddie11c
# WARNING: Dangerous script, will destroy all user files 

cd "/users"
ls > users.txt
UserCount=$( sed -n '$=' users.txt )
UserStart="1"
echo "Reading User directory, found ${UserCount} files or folders."

while [[ ${UserCount} > "0" ]]
do
	User=$( cat users.txt | Sed -n ${UserStart}p )
	UserCount=$(( ${UserCount}-1 ))
	User=$( echo ${User} | sed 's/Shared//' | sed 's/.DS_Store//' | sed 's/.localized//' | sed 's/ //' | sed 's/  //' | sed 's/users.txt//' )
	if [[ ${User} != "" ]]; then
		{
		echo "Removing User..${User}"
		/bin/launchctl "load" "/System/Library/LaunchDaemons/com.apple.DirectoryServices.plist" &
		dscl . -delete "/Users/${User}"
		rm -Rf "/Users/${User}"
		rm -Rf "/var/db/dslocal/nodes/Default/users/${User}.plist"
		}
	fi
	UserStart=$(( ${UserStart}+1 ))
done

rm -Rf text.txt
rm -Rf users.txt
cd "/"
rm /Library/Preferences/*.plist
cp "/Library/Preferences/SystemConfiguration/com.apple.Boot.plist" "/"
rm /Library/Preferences/SystemConfiguration/*.plist
rm "/var/db/.AppleSetupDone"
mv "com.apple.Boot.plist" "/Library/Preferences/SystemConfiguration/com.apple.Boot.plist"
chown -R root:wheel "/Library/Preferences/SystemConfiguration/com.apple.Boot.plist"
chmod -R 755 "/Library/Preferences/SystemConfiguration/com.apple.Boot.plist"

exit 0

			}
		fi
		done
exit 0 