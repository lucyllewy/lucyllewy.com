#!/bin/sh

# Script by eddie11c

Tools="/Library/Application Support/OSx86 Tool/"
CustomImagePath="/Library/Application Support/OSx86 Tool/Custom/"
BackupPath="/Library/Application Support/OSx86 Tool/Original/"
DefaultImageName="MacOSX.tif"
DefaultImagePath="/System/Library/CoreServices/loginwindow.app/Contents/Resources/"
cd "${Tools}"
CustomImageName=$( cat imagepath.txt | Sed -n 1p )
echo "Backup Image is located at:${CustomImageName}"
cp "${CustomImageName}" "${DefaultImagePath}${DefaultImageName}"
rm -Rf "${CustomImageName}"
rm -Rf "${Tools}imagepath.txt"

exit 0
