#!/usr/bin/env perl
#Backup script
if (-e "/Library/Preferences/SystemConfiguration/bootbackup.plist") {
	while (-e "/Library/Preferences/SystemConfiguration/bootbackup.plist-$count") {$count++;}
	qx/mv "\/Library\/Preferences\/SystemConfiguration\/bootbackup.plist" "\/Library\/Preferences\/SystemConfiguration\/bootbackup.plist-$count"/;
}
qx/cp "\/Library\/Preferences\/SystemConfiguration\/com.apple.Boot.plist" "\/Library\/Preferences\/SystemConfiguration\/bootbackup.plist"/;