#!/bin/sh

# Script by eddie11c

##Restore AboutThisMac.strings and AppleSystemInfo.strings

Tool="/Library/Application Support/OSx86 Tool/"
Strings="/System/Library/CoreServices/Resources/"
String="/System/Library/CoreServices/loginwindow.app/Contents/Resources/"
cd "${Tool}"

cp "${Tool}aboutthismac.txt" "${String}English.lproj/AboutThisMac.strings"
if [[ -f "${String}da.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}da.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}da.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}Dutch.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}Dutch.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}Dutch.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}fi.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}fi.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}fi.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}French.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}French.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}French.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}German.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}German.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}German.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}Japanese.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}Japanese.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}Japanese.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}ko.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}ko.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}ko.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}no.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}no.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}no.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}pl.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}pl.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}pl.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}pt_PT.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}pt_PT.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}pt_PT.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}pt.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}pt.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}pt.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}ru.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}ru.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}ru.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}Spanish.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}Spanish.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}Spanish.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}sv.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}sv.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}sv.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${String}zh_CN.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}zh_CN.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}zh_CN.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}zh_TW.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${String}zh_TW.lproj/AboutThisMac.strings"
	cp "${String}English.lproj/AboutThisMac.strings" "${String}zh_TW.lproj/AboutThisMac.strings"
	}
fi

cp strings.txt "${Strings}English.lproj/AppleSystemInfo.strings"
if [[ -f "${Strings}da.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}da.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}da.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}Dutch.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}Dutch.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}Dutch.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}fi.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}fi.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}fi.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}French.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}French.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}French.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}German.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}German.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}German.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}Japanese.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}Japanese.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}Japanese.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}ko.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}ko.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}ko.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}no.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}no.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}no.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}pl.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}pl.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}pl.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}pt_PT.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}pt_PT.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}pt_PT.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}pt.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}pt.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}pt.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}ru.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}ru.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}ru.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}Spanish.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}Spanish.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}Spanish.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}sv.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}sv.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}sv.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}zh_CN.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}zh_CN.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}zh_CN.lproj/AppleSystemInfo.strings"
	}
fi
if [[ -f "${Strings}zh_TW.lproj/AppleSystemInfo.strings" ]]; then
	{
	rm -f "${Strings}zh_TW.lproj/AppleSystemInfo.strings"
	cp "${Strings}English.lproj/AppleSystemInfo.strings" "${Strings}zh_TW.lproj/AppleSystemInfo.strings"
	}
fi

exit 0
