#!/bin/sh

# untitled.sh
# OSX86Tools
#
# Created by Indragie Karunaratne on 09/07/08.
# Copyright 2008 __MyCompanyName__. All rights reserved.

sed '1,4d' ~/Documents/OSX86ToolsGFX/temp.txt > ~/Documents/OSX86ToolsGFX/temp1.txt
mv ~/Documents/OSX86ToolsGFX/temp1.txt ~/Documents/OSX86ToolsGFX/temp.txt
sed 'N;$!P;$!D;$d' ~/Documents/OSX86ToolsGFX/temp.txt > ~/Documents/OSX86ToolsGFX/temp1.txt
mv ~/Documents/OSX86ToolsGFX/temp1.txt ~/Documents/OSX86ToolsGFX/temp.txt
