#!/bin/sh

# Script by eddie11c

Tool="/Library/Application Support/OSx86 Tool/"
Strings="/System/Library/CoreServices/loginwindow.app/Contents/Resources/"
cd "${Tool}"
file=$( cat raminfo.txt | sed -n 1p )
ram='"'$file'"'
cat aboutthismac.txt | sed 's_"%@%@"_'"$ram"'_' > ram1.txt
echo "${ram}"

if [[ -f "${Strings}English.lproj/AboutThisMac.strings.old" ]]; then
	rm -Rf "${Strings}English.lproj/AboutThisMac.strings.old"
fi

cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}English.lproj/AboutThisMac.strings.old"
rm -Rf "${Strings}English.lproj/AboutThisMac.strings"
cp ram1.txt "${Strings}English.lproj/AboutThisMac.strings"
rm -Rf "${Tool}ram1.txt"
rm -Rf "${Tool}raminfo.txt"


if [[ -f "${Strings}da.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}da.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}da.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}Dutch.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}Dutch.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}Dutch.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}fi.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}fi.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}fi.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}French.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}French.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}French.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}German.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}German.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}German.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}Japanese.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}Japanese.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}Japanese.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}ko.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}ko.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}ko.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}no.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}no.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}no.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}pl.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}pl.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}pl.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}pt_PT.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}pt_PT.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}pt_PT.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}pt.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}pt.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}pt.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}ru.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}ru.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}ru.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}Spanish.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}Spanish.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}Spanish.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}sv.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}sv.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}sv.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}zh_CN.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}zh_CN.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}zh_CN.lproj/AboutThisMac.strings"
	}
fi
if [[ -f "${Strings}zh_TW.lproj/AboutThisMac.strings" ]]; then
	{
	rm -f "${Strings}zh_TW.lproj/AboutThisMac.strings"
	cp "${Strings}English.lproj/AboutThisMac.strings" "${Strings}zh_TW.lproj/AboutThisMac.strings"
	}
fi

exit 0

